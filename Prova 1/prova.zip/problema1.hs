soma :: Int -> Int -> Int
soma 0 _ = 0
soma n p | mod p 5 /= 0 = p + 
